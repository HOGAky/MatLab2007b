function dYdt = motionODE(t, Y, Cd, S, m, rho0, g) 
vx = Y(1);
vy = Y(2);
v_mag = sqrt(vx^2 + vy^2);

dvx = - (Cd * rho0 * S * v_mag / (2 * m)) * vx;
dvy = - (Cd * rho0 * S * v_mag / (2 * m)) * vy - g;
dx  = vx;
dy  = vy;

dYdt = [dvx; dvy; dx; dy];
end