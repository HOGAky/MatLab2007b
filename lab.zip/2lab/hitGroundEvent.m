function [value, isterminal, direction] = hitGroundEvent(t, Y)
    value = Y(4);
    isterminal = 1;
    direction = -1;
end