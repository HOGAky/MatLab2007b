clear; clc; close all;

r = 5.3e-4;
rho = 13.55e3;
rho0 = 1.26e3;
mu = 1.48;
g = 9.81;

tspan = [0, 0.1];
Y0 = [0; 0];

odefun = @(t, Y) [
    g * (1 - rho0/rho) - (9 * mu * Y(1)) / (2 * r^2 * rho);
    Y(1)
];

[t, Y] = ode45(odefun, tspan, Y0);

v = Y(:, 1);
y = Y(:, 2);


figure('Name', 'v(t)', 'NumberTitle', 'off');
plot(t, v, 'b-', 'LineWidth', 2);
grid on;
xlabel('t, s');
ylabel('v, m/s');

figure('Name', 'y(t)', 'NumberTitle', 'off');
plot(t, y, 'r-', 'LineWidth', 2);
grid on;
xlabel('t, s');
ylabel('y, m');

figure('Name', 'Animation', 'NumberTitle', 'off');
hold on;
grid on;
axis equal;

margin = 0.001;
xlim([-margin, margin]);
ylim([-max(y) - margin, margin]);

ball = plot(0, 0, 'go', 'MarkerSize', 10, 'MarkerFaceColor', 'b');
trace = plot(0, 0, 'r--', 'LineWidth', 1);

for k = 1:length(t)
    set(ball, 'XData', 0, 'YData', -y(k));
    set(trace, 'XData', zeros(1, k), 'YData', -y(1:k));
    drawnow;
    pause(0.01);
end